﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDayApi.Models
{
    public class Result
    {
        [Key]
        public int ResultId { get; set; }

        [Required]
        [ForeignKey("Enrollment")]
        public int EnrollmentId { get; set; }

        public string FinishTime { get; set; } = string.Empty; // Format: "00:45:30"

        public int Position { get; set; }

        public int BibNumber { get; set; }

        public Enrollment? Enrollment { get; set; }
    }
}
