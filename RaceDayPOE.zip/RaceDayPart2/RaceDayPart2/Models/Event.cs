﻿using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RaceDayApi.Models
{
    public class Event
    {
        [Key]
        public int EventId { get; set; }

        [Required]
        [StringLength(100)]
        public string Title { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        [Required]
        public DateTime EventDate { get; set; }

        [StringLength(200)]
        public string Location { get; set; } = string.Empty;

        public int OrganiserId { get; set; }
        public User Organiser { get; set; }

        public int VenueId { get; set; }
        public Venue Venue { get; set; }

        public ICollection<Category> Categories { get; set; } = new List<Category>();
        public object Enrollment { get; internal set; }
    }
}