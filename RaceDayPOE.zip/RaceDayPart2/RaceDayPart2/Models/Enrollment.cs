﻿using Microsoft.Extensions.Logging;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDayApi.Models
{
    public class Enrollment
    {
        [Key]
        public int EnrollmentId { get; set; }

        [Required]
        [ForeignKey("User")]
        public int ParticipantId { get; set; }

        [Required]
        [ForeignKey("Category")]
        public int CategoryId { get; set; }

        [ForeignKey("Event")]
        public int EventId { get; set; }

        public DateTime EnrolledDate { get; set; } = DateTime.UtcNow;

        [StringLength(20)]
        public string Status { get; set; } = "Pending"; // e.g., "Pending", "Paid", "Cancelled"

        public User? Participant { get; set; }
        public Category? Category { get; set; }
        public Event? Event { get; set; }
        public Result? Result { get; set; }
    }
}
