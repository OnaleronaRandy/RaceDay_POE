﻿using Microsoft.Extensions.Logging;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDayApi.Models
{
    public class Category
    {
        [Key]
        public int CategoryId { get; set; }

        [Required]
        [ForeignKey("Event")]
        public int EventId { get; set; }

        [Required]
        [StringLength(50)]
        public string CategoryName { get; set; } = string.Empty; // e.g. "10km Run", "Senior 21km"

        public decimal DistanceKm { get; set; }

        public decimal Fee { get; set; }

        public Event? Event { get; set; }
    }
}
