﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayApi.Data;
using RaceDayApi.Dtos;

namespace RaceDayApi.Controllers
{
    [ApiController]
    [Route("api/organisers")]
    public class OrganisersController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public OrganisersController(RaceDayDbContext context) => _context = context;

        [HttpGet("{id}")]
        public async Task<IActionResult> GetOrganiser(int id)
        {
            var org = await _context.Users
                .Where(u => u.UserId == id && u.Role == "Organiser")
                .Select(u => new
                {
                    u.UserId,
                    u.FullName,
                    u.Email,
                    Events = u.Events.Select(e => new { e.EventId, e.Title, e.EventDate })
                })
                .FirstOrDefaultAsync();

            if (org == null) return NotFound();
            return Ok(org);
        }

        [HttpPut("profile")]
        [Authorize(Roles = "Organiser")]
        public IActionResult UpdateProfile([FromBody] UpdateOrganiserProfileDto dto)
        {
            return Ok("Updated organiser profile");
        }
    }

    [ApiController]
    [Route("api/venues")]
    public class VenuesController : ControllerBase
    {
        private readonly RaceDayDbContext _context;
        public VenuesController(RaceDayDbContext context) => _context = context;

        [HttpGet]
        public async Task<IActionResult> GetVenues()
        {
            return Ok(await _context.Venues.ToListAsync());
        }
    }
} 
