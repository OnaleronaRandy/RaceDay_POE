﻿namespace RaceDayApi.Dtos
{
    public record RegisterDto(string FullName, string Email, string Password, string Role);
    public record LoginDto(string Email, string Password);
    public record AuthResponseDto(int UserId, string FullName, string Email, string Role, string Token);
}