﻿namespace RaceDayApi.Dtos
{
    public record UpdateOrganiserProfileDto(string OrganizationName, string ContactPhone, string Website);
}
