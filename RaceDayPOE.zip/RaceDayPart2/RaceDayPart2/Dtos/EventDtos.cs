﻿using System;

namespace RaceDayApi.Dtos
{
    public record CreateEventDto(string Title, string Description, DateTime EventDate, int VenueId);
    public record UpdateEventDto(string Title, string Description, DateTime EventDate, int VenueId);
}