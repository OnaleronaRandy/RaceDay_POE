﻿using RaceDay.MVC.Models;
using System.Net.Http.Json;

namespace RaceDay.MVC.Services
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;

        public ApiService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;

            // This reads your BaseUrl from appsettings.json
            var baseUrl = configuration["ApiSettings:BaseUrl"];
            if (!string.IsNullOrEmpty(baseUrl))
            {
                _httpClient.BaseAddress = new Uri(baseUrl);
            }
        }

        // Example method to fetch events from your Part 2 API
        public async Task<List<EventViewModel>> GetEventsAsync()
        {
            try
            {
                var events = await _httpClient.GetFromJsonAsync<List<EventViewModel>>("api/events");
                return events ?? new List<EventViewModel>();
            }
            catch
            {
                // Returns an empty list gracefully if the API is offline or fails
                return new List<EventViewModel>();
            }
        }
    }
}
