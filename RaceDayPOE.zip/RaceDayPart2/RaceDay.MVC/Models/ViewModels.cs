﻿namespace RaceDay.MVC.Models
{
    public class EventViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime Date { get; set; }
        public string Location { get; set; }
        public decimal Distance { get; set; }
        public string BannerUrl { get; set; }
        public IFormFile BannerImage { get; set; }
    }

    public class LoginViewModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class EnrollmentViewModel
    {
        public int Id { get; set; }
        public string EventName { get; set; }
        public DateTime EventDate { get; set; }
        public string CategoryName { get; set; }
        public string Status { get; set; } // Confirmed, Pending, etc.
    }
}

